"""Чтение полного CSV-экспорта train_solo_track.parquet для Codex.
Запуск: python rwb_codex_read_train.py [путь_к_train_solo_track_full.csv.gz]
Требует: pandas. Для CSV-экспорта pyarrow не нужен.
"""
from pathlib import Path
import sys
import pandas as pd

csv_path = Path(sys.argv[1]) if len(sys.argv) > 1 else next(
    (p for p in (Path("train_solo_track_full.csv"), Path("train_solo_track_full.csv.gz")) if p.is_file()),
    Path("train_solo_track_full.csv"),
)
if not csv_path.is_file():
    raise FileNotFoundError(f"Не найден файл: {csv_path.resolve()}")

train = pd.read_csv(csv_path, parse_dates=["timestamp"])
print("Размер:", train.shape)
print("Столбцы:", train.columns.tolist())
print("Маршрутов:", train["route_id"].nunique())
print("Временной период:", train["timestamp"].min(), "—", train["timestamp"].max())
print("Пропуски:\n", train.isna().sum().to_string())
print("Дубликаты маршрут/время:", train.duplicated(["route_id", "timestamp"]).sum())
print("Статистика target_1h:\n", train["target_1h"].describe().to_string())
print("Первые строки:\n", train.head(10).to_string(index=False))
